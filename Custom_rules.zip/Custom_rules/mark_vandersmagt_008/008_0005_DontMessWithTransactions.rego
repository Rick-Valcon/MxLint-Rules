# METADATA
# scope: package
# title: Disallowed transaction handling Java actions
# description: DontMessWithTransactions
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: DontMessWithTransactions
#  severity: HIGH
#  rulenumber: 008_0005
#  remediation: Use the Mendix TaskQueue when you want to execute logic in batches.
#  input: .*\.Microflows\$Microflow\.yaml

package app.mendix.microflow.dontmesswithtransactions

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false

# Policy passes if no errors are found
allow if count(errors) == 0

# ---------------------------------------------------------
# Forbidden Java Actions
# ---------------------------------------------------------
forbidden_java_actions := {
  "objecthandling.starttransaction",
  "objecthandling.endtransaction",
  "communitycommons.starttransaction",
  "communitycommons.endtransaction"
}

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------
errors contains err if {
  a := java_actions[_]

  action_name := lower(object.get(a, "JavaAction", ""))
  action_name != ""

  action_name == forbidden_java_actions[_]

  err := sprintf("[%v, %v, %v] %v - Forbidden Java action used: %v",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      action_name
    ]
  )
}

# ---------------------------------------------------------
# Extract Java actions
# ---------------------------------------------------------
java_actions := [a |
  action_activity := microflow_objects[_]
  action_activity["$Type"] == "Microflows$ActionActivity"

  a := object.get(action_activity, "Action", null)
  a != null

  contains(lower(type_of(a)), "javaaction")
]

# ---------------------------------------------------------
# Object collection helper
# ---------------------------------------------------------
microflow_objects := objs if {
  objs := input.ObjectCollection.Objects
} else := [] if {
  true
}

# ---------------------------------------------------------
# TYPE HELPER
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if {
  true
}
