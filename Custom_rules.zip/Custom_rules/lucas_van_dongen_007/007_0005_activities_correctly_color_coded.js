const metadata = {
    scope: "package",
    title: "Validate activity colors in microflows",
    description: "Ensures activities use the correct color based on their purpose.",
    authors: ["Lucas van Dongen"],
    custom: {
        category: "Maintainability",
        rulename: "MicroflowColorCoding",
        severity: "LOW",
        rulenumber: "007_0005",
        remediation: "Adjust activity colors to match Mendix best practices.",
        input: ".*\\$Microflow\\.yaml"
    }
};

function getAction(activity) {
    return activity.Action || {};
}

function getActionType(activity) {
    return getAction(activity).$Type || "";
}

function getEntity(activity) {
    const action = getAction(activity);
    const actionType = getActionType(activity);

    switch (actionType) {
        case "Microflows$CreateChangeAction":
            return action.Entity || "";

        case "Microflows$ChangeAction":
            return action.ChangeVariableName || "";

        case "Microflows$RetrieveAction":
            return action.RetrieveSource?.StartVariableName || "";

        default:
            return "";
    }
}

function entityName(entityRef) {
    const parts = entityRef.split(".");
    return parts[parts.length - 1];
}
 
function isNPE(entity) {
    // read the parent domain model and check if the entity is NPE
    // entity: Module2.EntityNonPersist
    if (entity === undefined) {
        return false;
    }
    const moduleName = entity.split(".")[0];
    const domainModelPath = [moduleName, "DomainModels$DomainModel.yaml"].join("/");
    const domainModel = mxlint.io.readYaml(domainModelPath);
    if (domainModel === undefined || domainModel.Entities === undefined) {
        return false;
    }
    const name = entityName(entity);
    const found = domainModel.Entities.find(e => e.Name === name);
    if (found === undefined || found.MaybeGeneralization === undefined) {
        return false;
    }
    return found.MaybeGeneralization.Persistable === false;
}

function resolveColor(actionType, commit, entity) {
    // 🟡 Variable actions
    if (
        actionType === "Microflows$CreateVariableAction" ||
        actionType === "Microflows$ChangeVariableAction"
    ) {
        return "Yellow";
    }

    // 🔴 Delete
    if (actionType === "Microflows$DeleteAction") {
        return "Red";
    }

    // 🟢 Microflow call
    if (actionType === "Microflows$MicroflowCallAction") {
        return "Green";
    }

    // ⚪ Log
    if (actionType === "Microflows$LogMessageAction") {
        return "Gray";
    }

    // 🟣 Commit logic
    if (actionType === "Microflows$CommitAction") {
        return "Purple";
    }

    if (
        actionType === "Microflows$ChangeAction" &&
        commit === "Yes"
    ) {
        return "Purple";
    }

    if (
        actionType === "Microflows$CreateChangeAction" &&
        commit === "Yes"
    ) {
        return "Purple";
    }

    // 🟠 Non-persistent entities
    if (
        actionType === "Microflows$CreateChangeAction" &&
        commit !== "Yes" &&
        isNPE(entity)
    ) {
        return "Orange";
    }

    if (
        actionType === "Microflows$ChangeAction" &&
        commit !== "Yes" &&
        isNPE(entity)
    ) {
        return "Orange";
    }

    if (
        actionType === "Microflows$RetrieveAction" &&
        isNPE(entity)
    ) {
        return "Orange";
    }

    // 🔵 Everything else
    return "Default";
}

function expectedColor(activity) {
    const action = getAction(activity);
    const actionType = action.$Type || "";
    const commit = action.Commit || "No";
    const entity = getEntity(activity);

    return resolveColor(actionType, commit, entity);
}

function rule(input = {}) {
    const errors = [];

    const objects = input.ObjectCollection?.Objects || [];

    const activities = objects.filter(
        o => o.$Type === "Microflows$ActionActivity"
    );
 
    for (const activity of activities) {
        try {
            const expected = expectedColor(activity);
            const actual = activity.BackgroundColor || "Default";

            if (expected !== actual) {
                const actionType = getActionType(activity);

                const microflowName =
                    input.Name || "Microflow (unknown name)";

                const caption =
                    activity.Caption || "Unnamed activity";

                errors.push(
                    `[${metadata.custom.severity}, ` +
                    `${metadata.custom.category}, ` +
                    `${metadata.custom.rulenumber}] ` +
                    `Microflow '${microflowName}': ` +
                    `Activity '${caption}' (${actionType}) ` +
                    `has color '${actual}' but should be '${expected}'.`
                );
            }
        } catch (e) {
            errors.push(
                `Failed to validate activity color: ${e.message || e}`
            );
        }
    }
    errors.push(mxlint);
    return {
        allow: errors.length === 0,
        errors
    };
}