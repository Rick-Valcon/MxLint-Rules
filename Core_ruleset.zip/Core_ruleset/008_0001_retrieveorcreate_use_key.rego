# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: Reduce the amount of input parameters per microflow to improve maintainability and reuse. Setting only the key values in retrieve or create microflows is essential for maintaining your application. It stimulates reuse within the application and reduces complexity of creating objects by providing consistent creation of entities within the application. Required changes to the object are performed after the Retrieve or Create microflow to minimize the changes of a single attribute
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: RetrieveOrCreateUseKey
#  severity: MEDIUM
#  rulenumber: 008_0001
#  remediation: The created object must match the retrieved object. Every inputparameter must also be used in the retrieve. Every attribute that is queried on in the retrieve on must also be set in the create. Use only the key values as input parameters and use only these to retrieve AND create the object.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# RULE 1: EACH PARAM (OR DERIVED) MUST BE USED IN RETRIEVE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow

  p := input_parameters[_]
  group := valid_representations[p]

  not exists_in_retrieve_base(group)

  err := sprintf("[%v, %v, %v] %v - Parameter '%v' (or derived: %v) not used in retrieve (retrieve: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      p,
      group,
      retrieve_all
    ]
  )
}


# ---------------------------------------------------------
# MICROFLOW TYPE
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

# ---------------------------------------------------------
# INPUT PARAMETERS
# ---------------------------------------------------------
input_parameters := {p |
  o := microflow_objects[_]
  contains(lower(type_of(o)), "microflowparameter")
  p := o.Name
}

# ---------------------------------------------------------
# GROUP INPUT PARAMETER WITH DERIVATIONS INTO REPRESENTATION (2 LEVELS)
# ---------------------------------------------------------

valid_representations[p] := reps if {
  p := input_parameters[_]

  lvl1 := {v |
    pair := param_derivation_lvl1[_]
    pair[0] == p
    v := pair[1]
  }

  lvl2 := {v |
    pair := param_derivation_lvl2[_]
    pair[0] == p
    v := pair[1]
  }

  reps := {p} | lvl1 | lvl2
}

param_derivation_lvl1 := { [p, v] |
  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_xpath_vars(expr)

  vx := vars[_]
  base := base_var(vx)

  input_parameters[base]

  p := base

  v := object.get(act, "VariableName", "")
  v != ""
}

param_derivation_lvl2 := { [p, v2] |
  pair := param_derivation_lvl1[_]
  p := pair[0]
  v1 := pair[1]

  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_xpath_vars(expr)

  vx := vars[_]
  base_var(vx) == v1

  v2 := object.get(act, "VariableName", "")
  v2 != ""
}

is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------

exists_in_retrieve_base(group) if {
  some v
  group[v]
  retrieve_base[v]
}

# Normalized retrieve (for param coverage only)
retrieve_base := {b |
  v := retrieve_all[_]
  b := base_var(v)
}

retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
}

# Assoc retrieve
retrieve_assoc_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_xpath_vars(xpath)[_]
}

# XPATH VARIABLE EXTRACTION
extract_xpath_vars(xpath) := vars if {
  normalized := replace(replace(replace(replace(replace(replace(xpath, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") 
  parts := split(normalized, " ")

  vars := {trim_prefix(p, "$") |
    p := parts[_]
    startswith(p, "$")
  }
}


# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------
# Normalize variable to its base (before '/')
base_var(v) := b if {
  parts := split(v, "/")
  b := parts[0]
}

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }



# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

microflow_objects := objs if {
  objs := input.ObjectCollection.Objects
} else := [] if { true }



