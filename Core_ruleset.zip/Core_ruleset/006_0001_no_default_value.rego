# METADATA
# scope: package
# title: Do not use default values on attributes
# description: Avoid default values because it introduces hidden logic that is hard to detect via "find changes".
# authors:
# - Rick Schreuder
# custom:
#  category: Maintainability
#  rulename: NoDefaultValue
#  severity: LOW
#  rulenumber: 006_0001
#  remediation: Remove the attribute default value and set it explicitly in logic where needed.
#  input: .*DomainModels\$DomainModel\.yaml

package app.mendix.domain_model.no_default_value

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

default_value_is_set(default_value) if {
  default_value != null
  not is_empty_string(default_value)
}

is_empty_string(value) if {
  is_string(value)
  value == ""
}

is_excluded_attribute_type(attribute_type_string) if {
  attribute_type_string == "DomainModels$BooleanAttributeType"
} else if {
  attribute_type_string == "DomainModels$AutoNumberAttributeType"
}

errors contains error_message if {
  some entity_index
  some attribute_index

  domain_model_entity := input.Entities[entity_index]
  domain_model_attribute := domain_model_entity.Attributes[attribute_index]

  attribute_value_block := object.get(domain_model_attribute, "Value", {})
  attribute_default_value := object.get(attribute_value_block, "DefaultValue", null)

  default_value_is_set(attribute_default_value)

  attribute_type_block := object.get(domain_model_attribute, "NewType", {})
  attribute_type_string := object.get(attribute_type_block, "$Type", "")

  # Boolean and AutoNumber always have a tooling/default value and should not be flagged.
  not is_excluded_attribute_type(attribute_type_string)

  error_message := sprintf(
    "[%v, %v, %v] %v.%v has a default value set",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      domain_model_entity.Name,
      domain_model_attribute.Name
    ]
  )
}