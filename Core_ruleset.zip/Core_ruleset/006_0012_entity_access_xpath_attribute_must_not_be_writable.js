const metadata = {
    scope: "package",
    title: "Entity access XPath attributes must not be writable",
    description: "Detects entity access rules where a user role has write access to an attribute that is also used in the XPath constraint of the same access rule.",
    authors: ["Rick Schreuder"],
    custom: {
        category: "Security",
        rulename: "EntityAccessXPathAttributeMustNotBeWritable",
        severity: "HIGH",
        rulenumber: "006_0012",
        remediation: "Do not give write access to attributes that are used to restrict entity access in XPath constraints. Use separate immutable status fields, role based logic, or microflow controlled transitions.",
        input: ".*DomainModels\\$DomainModel\\.yaml"
    }
};

/**
 * Main MxLint rule entry point.
 * Checks each entity access rule and reports attributes that are both used in the XPath constraint and writable for the same role.
 */

function rule(input = {}) {
    const errors = [];

    const entities = Array.isArray(input.Entities) ? input.Entities : [];

    for (const entity of entities) {
        const entityName = entity.Name || "<unknown entity>";
        const accessRules = Array.isArray(entity.AccessRules) ? entity.AccessRules : [];
        const attributes = Array.isArray(entity.Attributes) ? entity.Attributes : [];

        const attributeNames = attributes
            .map(attr => attr.Name)
            .filter(Boolean);

        for (const accessRule of accessRules) {
            const xpath = getXPathConstraint(accessRule);

            if (!xpath) {
                continue;
            }

            const xpathAttributes = getAttributesUsedInXPath(xpath, attributeNames);
            const writableAttributes = getWritableAttributes(accessRule);

            const unsafeAttributes = [...xpathAttributes].filter(attr =>
                writableAttributes.has(attr)
            );

            if (unsafeAttributes.length > 0) {
                const roles = getAllowedRoles(accessRule);

                errors.push(
                    `[${metadata.custom.severity}, ${metadata.custom.category}, ${metadata.custom.rulenumber}] ` +
                    `Entity ${entityName} has an entity access XPath that depends on writable attribute(s): ` +
                    `${unsafeAttributes.join(", ")}. ` +
                    `Roles: ${roles.length > 0 ? roles.join(", ") : "<unknown roles>"}. ` +
                    `XPath: ${xpath}`
                );
            }
        }
    }

    return {
        allow: errors.length === 0,
        errors
    };
}

/**
 * Extracts the XPath constraint from an access rule.
 * Supports multiple possible field names to handle different export structures.
 */
function getXPathConstraint(accessRule) {
    const candidates = [
        accessRule.XPathConstraint,
        accessRule.XpathConstraint,
        accessRule.XPath,
        accessRule.Constraint,
        accessRule.Expression
    ];

    for (const candidate of candidates) {
        const value = normalizeXPathValue(candidate);
        if (value) {
            return value;
        }
    }

    return "";
}

/**
 * Converts an XPath value to a clean string.
 * Handles plain strings and nested object structures that may contain the XPath expression.
 */
function normalizeXPathValue(value) {
    if (value === null || value === undefined) {
        return "";
    }

    if (typeof value === "string") {
        return value.trim();
    }

    if (typeof value === "object") {
        const nestedCandidates = [
            value.Constraint,
            value.Expression,
            value.XPath,
            value.Value,
            value.Text
        ];

        for (const candidate of nestedCandidates) {
            const normalized = normalizeXPathValue(candidate);
            if (normalized) {
                return normalized;
            }
        }
    }

    return "";
}

/**
 * Returns all attributes that are writable in the given access rule.
 * Member access is considered writable when its access rights indicate write or read write access.
 */
function getWritableAttributes(accessRule) {
    const result = new Set();

    const memberAccesses = Array.isArray(accessRule.MemberAccesses)
        ? accessRule.MemberAccesses
        : [];

    for (const memberAccess of memberAccesses) {
        const accessRights = String(
            memberAccess.AccessRights ||
            memberAccess.Access ||
            memberAccess.MemberAccess ||
            ""
        ).toLowerCase();

        const isWritable =
            accessRights.includes("write") ||
            accessRights.includes("readwrite") ||
            accessRights === "writable";

        if (!isWritable) {
            continue;
        }

        const rawAttribute =
            memberAccess.Attribute ||
            memberAccess.Member ||
            memberAccess.Name ||
            "";

        const attributeName = getLastNamePart(rawAttribute);

        if (attributeName) {
            result.add(attributeName);
        }
    }

    return result;
}

/**
 * Finds which entity attributes are referenced in the XPath constraint.
 * Compares the XPath text against the list of attributes defined on the entity.
 */

function getAttributesUsedInXPath(xpath, attributeNames) {
    const result = new Set();

    for (const attr of attributeNames) {
        if (attributeIsUsedInXPath(xpath, attr)) {
            result.add(attr);
        }
    }

    return result;
}

/**
 * Checks whether a specific attribute name is used in an XPath constraint.
 * Uses regex patterns to avoid matching unrelated partial words.
 */
function attributeIsUsedInXPath(xpath, attributeName) {
    const escaped = escapeRegExp(attributeName);

    const patterns = [
        new RegExp(`\\b${escaped}\\b`, "i"),
        new RegExp(`\\/${escaped}\\b`, "i"),
        new RegExp(`\\[\\s*${escaped}\\s*[=!<>]`, "i"),
        new RegExp(`\\[.*\\/${escaped}\\s*[=!<>]`, "i")
    ];

    return patterns.some(pattern => pattern.test(xpath));
}

/**
 * Returns the module roles assigned to an access rule.
 * Supports both AllowedModuleRoles and ModuleRoles fields.
 */
function getAllowedRoles(accessRule) {
    const roles = accessRule.AllowedModuleRoles || accessRule.ModuleRoles || [];

    if (!Array.isArray(roles)) {
        return [];
    }

    return roles.map(role => String(role));
}

/**
 * Extracts the final name segment from a fully qualified Mendix name.
 * Example: MyModule.Order.Status becomes Status.
 */
function getLastNamePart(value) {
    if (!value) {
        return "";
    }

    const parts = String(value).split(".");
    return parts[parts.length - 1];
}

/**
 * Escapes special regex characters in a string.
 * This allows attribute names to be safely used inside regular expressions.
 */
function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}