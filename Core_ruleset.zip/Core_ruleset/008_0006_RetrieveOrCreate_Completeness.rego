# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: The create must match the retrieve or duplicate objects will be created.
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: RetrieveOrCreateCompleteness
#  severity: HIGH
#  rulenumber: 008_0006
#  remediation: Make sure that the created object matches the entity and attributes that are being retrieved. Also make sure that the created object is used as return parameter.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_completeness

import rego.v1

# GENERATED FILE - do not edit the .rego output directly.
# Source: src/rules/008_0006_retrieveorcreate_completeness.rule.part
# plus shared parts listed in generate.sh, assembled by generate.sh.
#
# Note: original file declared `package app.mendix.domain_model.retrieveorcreate_use_key`,
# identical to 008_0001's package name. That was harmless under mxlint-cli (each .rego
# file is compiled/evaluated in isolation - see repo README.txt for why),
# but misleading and unsafe under plain `opa test`, which would merge same-package files
# across a directory. Renamed to its own package here.
#
# Note: the original file also defined an `exists_in_retrieve(group)` helper that was
# never referenced by any of this rule's checks (leftover from copy-pasting 008_0001).
# Dropped as dead code.

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0


# ---------------------------------------------------------
# RULE 1: RETRIEVE VARIABLES MUST EXIST IN CREATE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  missing := {x |
    x := retrieve_all[_]
    not create_all[x]
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] Not all variables used in retrieve are set in create (retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      retrieve_all,
      create_all
    ]
  )
}

# ---------------------------------------------------------
# RULE 2: ENTITY MATCH
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  retrieve := database_retrieve_entity
  count(retrieve) != 0

  create := create_entity

  missing := {x |
    some i
    x := create[i]
    not retrieve[x] #True if retrieve contains x
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] Retrieved and created entities differ (retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      retrieve,
      create
    ]
  )
}

# ---------------------------------------------------------
# RULE 3: END EVENTS MUST RETURN AT LEAST TWO DIFFERENT VARIABLES
# ---------------------------------------------------------
# A retrieve-or-create microflow branches into a "found" path and a
# "created" path, so it must have at least two distinct end-event return
# values. Checking for "fewer than 2 distinct values" (rather than
# comparing a deduplicated set against a raw count of end events) also
# catches the case where two end events are byte-for-byte identical:
# all_microflow_objects is itself a set, so two structurally identical
# EndEvent objects collapse into a single set member before this rule
# ever sees them, which would defeat a duplicate-count comparison.
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  # Collect all end event return values
  returns := {rv |
    o := all_microflow_objects[_]
    contains(lower(type_of(o)), "endevent")

    raw := object.get(o, "ReturnValue", "")
    raw != ""

    # normalize
    without_dollar := trim_prefix(raw, "$")
    rv := trim(without_dollar, " \t\r\n")
  }

  count(returns) < 2

  err := sprintf("[%v, %v, %v] End events must return at least two different variables (found: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      returns
    ]
  )
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------
retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
}

# ---------------------------------------------------------
# CREATE VARIABLES
# ---------------------------------------------------------

create_all := {v |
  used_variables_in_create[v]
}


used_variables_in_create := direct_create_vars | relinked_helper_vars

# Variables set directly as an attribute/association value on the
# created (or changed) object, e.g. NewPerson.HouseHold = $HouseHold.
direct_create_vars := {vd |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "changeaction")

  items := object.get(a, "Items", [])
  item := items[_]

  val := object.get(item, "Value", "")
  startswith(val, "$")

  raw := trim_prefix(val, "$")
  vd := trim(raw, " \t\r\n")
}

# Variables satisfied by linking the newly created object back onto them
# instead (e.g. a "retrieve via helper" pattern: PersonHelper is used to
# retrieve Person, and instead of setting PersonHelper as a key on the
# new Person, a separate ChangeAction sets PersonHelper's association to
# the newly created object: PersonHelper.Person = $NewPerson).
relinked_helper_vars := {vd |
  a := actions[_]
  contains(lower(type_of(a)), "changeaction")
  not contains(lower(type_of(a)), "createchangeaction")

  change_var := object.get(a, "ChangeVariableName", "")
  change_var != ""

  items := object.get(a, "Items", [])
  item := items[_]

  assoc := object.get(item, "Association", "")
  assoc != ""

  val := object.get(item, "Value", "")
  startswith(val, "$")
  raw := trim_prefix(val, "$")
  target := trim(raw, " \t\r\n")

  target == created_object_vars[_]

  vd := change_var
}

# The result variable(s) of the create step(s) in this microflow.
created_object_vars := {v |
  a := actions[_]
  contains(lower(type_of(a)), "createchangeaction")
  v := object.get(a, "VariableName", "")
  v != ""
}

# ---------------------------------------------------------
# ENTITY EXTRACTION
# ---------------------------------------------------------
database_retrieve_entity := {ent |
  a := actions[_]
  contains(lower(type_of(a)), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null

  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  ent := object.get(src, "Entity", "")
  ent != ""
}

create_entity := {ent |
  a := actions[_]
  is_create_change_action(a)
  ent := a.Entity
}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------

is_create_change_action(a) if {
  contains(lower(type_of(a)), "changeaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables derived from $latestError via a Create or Change variable
# action whose InitialValue/Value contains "$latestError" (e.g.
# $ErrorMsg := $latestError/Message). Lets a rule recognize error-handling
# code that references the error indirectly through such a variable, not
# just $latestError itself.
#
# Was previously hand-duplicated (byte-for-byte) inside both
# 008_0004_custom_error_handling_latest_error_usage.rule.part and
# 008_0015_no_raw_error_messages_to_user.rule.part - consolidated here.
#
# Depends on: microflow_object_tree.rego.part (actions),
#             is_create_variable_action.rego.part,
#             is_change_variable_action.rego.part
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
  act := actions[_]
  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")
  contains(expr, "$latestError")

  v := object.get(act, "VariableName", "")
  v != ""
}

derived_change_vars := {v |
  act := actions[_]
  is_change_variable_action(act)

  expr := object.get(act, "Value", "")
  contains(expr, "$latestError")

  v := object.get(act, "ChangeVariableName", "")
  v != ""
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_change_variable_action(a) if {
  contains(lower(type_of(a)), "changevariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one set, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
