# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: The variables used in the retrieve must be set in the create or duplicate objects will be created. End event's must not contain duplicate objects.
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: RetrieveOrCreateCompleteness
#  severity: HIGH
#  rulenumber: 008_0006
#  remediation: The created object must match the retrieved object. Every attribute that is queried on in the retrieve on must also be set in the create. Use only the key values as input parameters and use only these to retrieve AND create the object.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0


# ---------------------------------------------------------
# RULE 1: RETRIEVE VARIABLES MUST EXIST IN CREATE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow

  missing := {x |
    x := retrieve_all[_]
    not create_all[x]
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] %v - Not all variables used in retrieve are set in create (missing: %v, retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      missing,
      retrieve_all,
      create_all
    ]
  )
}

# ---------------------------------------------------------
# RULE 2: ENTITY MATCH
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow

  retrieve := database_retrieve_entity
  count(retrieve) != 0

  create := create_entity

  missing := {x |
    some i
    x := create[i]
    not retrieve[x] #True if retrieve contains x
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] %v - Retrieved and created entities differ (retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      retrieve,
      create
    ]
  )
}

# ---------------------------------------------------------
# RULE 3: END EVENTS MUST RETURN DIFFERENT VARIABLES
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow

  # Collect all end event return values
  returns := {rv |
    o := microflow_objects[_]
    contains(lower(type_of(o)), "endevent")

    raw := object.get(o, "ReturnValue", "")
    raw != ""

    # normalize
    without_dollar := trim_prefix(raw, "$")
    rv := trim(without_dollar, " \t\r\n")
  }

  # if duplicates exist, count(set) < count(all occurrences)
  count(returns) < count([rv |
    o := microflow_objects[_]
    contains(lower(type_of(o)), "endevent")

    raw := object.get(o, "ReturnValue", "")
    raw != ""

    without_dollar := trim_prefix(raw, "$")
    rv := trim(without_dollar, " \t\r\n")
  ])

  err := sprintf("[%v, %v, %v] %v - End events must return different variables (found: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      returns
    ]
  )
}

# ---------------------------------------------------------
# MICROFLOW TYPE
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------
exists_in_retrieve(group) if {
  some v
  group[v]
  retrieve_all[v]
}

retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
}

# Assoc retrieve
retrieve_assoc_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPath retrieve
retrieve_xpath_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_xpath_vars(xpath)[_]
}


# XPATH VARIABLE EXTRACTION
extract_xpath_vars(xpath) := vars if {
  normalized := replace(replace(replace(replace(replace(replace(xpath, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") 
  parts := split(normalized, " ")

  vars := {trim_prefix(p, "$") |
    p := parts[_]
    startswith(p, "$")
  }
}


# ---------------------------------------------------------
# CREATE VARIABLES
# ---------------------------------------------------------

create_all := {v |
  used_variables_in_create[v]
}


used_variables_in_create := {vd |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "changeaction")

  items := object.get(a, "Items", [])
  item := items[_]

  val := object.get(item, "Value", "")
  startswith(val, "$")

  raw := trim_prefix(val, "$")
  vd := trim(raw, " \t\r\n")
}

# ---------------------------------------------------------
# ENTITY EXTRACTION
# ---------------------------------------------------------
database_retrieve_entity := {ent |
  a := actions[_]
  contains(lower(type_of(a)), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null

  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  ent := object.get(src, "Entity", "")
  ent != ""
}

create_entity := {ent |
  a := actions[_]
  is_create_change_action(a)
  ent := a.Entity
}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------

is_create_change_action(a) if {
  contains(lower(type_of(a)), "changeaction")
}

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }


# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

microflow_objects := objs if {
  objs := input.ObjectCollection.Objects
} else := [] if { true }
