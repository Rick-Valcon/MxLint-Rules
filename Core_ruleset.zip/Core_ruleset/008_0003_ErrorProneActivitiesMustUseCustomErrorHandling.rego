# METADATA
# scope: package
# title: Error-prone activities must use custom error handling
# description: Enforces Custom error handling (with or without rollback) for error-prone activities. Error-prone activities are either (1) explicitly risky action types (Java actions, import/export mappings) or (2) any action that contains error-prone expression functions (e.g., parseDateTime, substring) anywhere within its Action definition.
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: ErrorProneActivitiesMustUseCustomErrorHandling
#  severity: HIGH
#  rulenumber: 008_0003
#  remediation: Set ErrorHandlingType to CustomWithRollback or CustomWithoutRollBack and write a logmessage that contains the $latestError information aswell as object information (e.g OrderId).
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.error_prone_custom_error_handling

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# Maintainable config
# ---------------------------------------------------------

always_error_prone_action_types := [
  {"match": "microflows$javaactioncallaction", "label": "Java action"},
  {"match": "microflows$importxmlaction",      "label": "Import mapping (ImportXmlAction)"},
  {"match": "microflows$restcallaction",      "label": "Call REST"},
  {"match": "microflows$restoperationcallaction",      "label": "Send REST request"},
  {"match": "microflows$callwebserviceaction",      "label": "Call Web Service"},
  {"match": "microflows$callexternalaction",      "label": "Call external action"}
]

error_prone_expression_functions := {
  "substring",
  "parseDateTime",
  "parseDateTimeUTC",
  "parseDecimal"
}

allowed_error_handling := {
  "customwithrollback",
  "customwithoutrollback"
}

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------

errors contains err if {
  ep := error_prone_action_activities[_]
  a := ep.action

  not error_handling_ok(a)

  kind  := ep.kind_label
  atype := type_of(a)

  # Use Caption from the ActionActivity (preferred), fallback to old display logic
  name := ep.caption

  funcs := error_prone_functions_in_action(a)

  err := sprintf("[%v, %v, %v] %v - %v must use custom error handling (action: %v, type: %v, error_prone: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      annotation.title,
      kind,
      name,
      atype,
      funcs
    ]
  )
}

# ---------------------------------------------------------
# Determine which activities are error-prone
# ---------------------------------------------------------

error_prone_action_activities := [info |
  aa := action_activities[_]
  a := object.get(aa, "Action", null)
  a != null

  kind := error_prone_kind_label(a)

  info := {
    "activity": aa,
    "action": a,
    "kind_label": kind,

    # Caption is what we report as "action" in messages
    # Fallback: try old name inference if caption missing
    "caption": activity_caption(aa)
  }
]

error_prone_kind_label(a) := label if {
  label := always_error_prone_label(a)
} else := "Activities that contain error prone expressions" if {
  action_contains_error_prone_expression(a)
}

always_error_prone_label(a) := label if {
  t := lower(type_of(a))
  d := always_error_prone_action_types[_]
  contains(t, d.match)
  label := d.label
}

# ---------------------------------------------------------
# Caption helper (preferred action name in output)
# ---------------------------------------------------------

activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := "UNKNOWN" if { true }

# ---------------------------------------------------------
# Expression scanning (type-independent)
# ---------------------------------------------------------

action_contains_error_prone_expression(a) if {
  some s in strings_in_object(a)
  expr_contains_error_prone_function(s)
}

strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

expr_contains_error_prone_function(expr) if {
  e := lower(expr)
  fn := error_prone_expression_functions[_]
  contains(e, sprintf("%v(", [fn]))
}

error_prone_functions_in_action(a) := funcs if {
  funcs := {fn |
    some s in strings_in_object(a)
    e := lower(s)
    fn := error_prone_expression_functions[_]
    contains(e, sprintf("%v(", [fn]))
  }
} else := {} if { true }

# ---------------------------------------------------------
# Error handling checks
# ---------------------------------------------------------

error_handling_ok(a) if {
  eht_raw := object.get(a, "ErrorHandlingType", "")
  eht_raw != ""
  eht := normalize_eht(eht_raw)
  eht in allowed_error_handling
}

normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

# ---------------------------------------------------------
# Microflow traversal helpers
# ---------------------------------------------------------

microflow_objects := objs if {
  objs := input.ObjectCollection.Objects
} else := [] if { true }

action_activities := [o |
  o := microflow_objects[_]
  o["$Type"] == "Microflows$ActionActivity"
]

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
