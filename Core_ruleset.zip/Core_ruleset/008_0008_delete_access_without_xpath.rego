# METADATA
# scope: package
# title: Delete access granted without XPath constraint
# description: Deletes are best executed from a microflow, where usages are easier to find and control. Granting entity-level Delete access is a valid alternative, but only when it is scoped down with an XPath constraint - otherwise the role can delete every record of the entity. Non-persistent entities are exempt, since they have no stored records to wipe.
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: DeleteAccessWithoutXPath
#  severity: MEDIUM
#  rulenumber: 008_0008
#  remediation: Add an XPath constraint to the access rule so Delete is limited to the records this role should actually be able to remove, or perform the delete from a microflow instead of granting entity-level Delete access.
#  input: .*DomainModels\$DomainModel\.yaml
package app.mendix.domain_model.delete_access_without_xpath

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

errors contains err if {
  entity := input.Entities[_]

  # Non-persistent entities have no stored records to wipe, so
  # unconstrained Delete access on them is not a risk. Persistable only
  # lives on MaybeGeneralization for a NoGeneralization entity; an entity
  # that generalizes from another one has no local Persistable field, so
  # default to true (treat as persistent, i.e. still scan it) rather than
  # assume it's safe.
  maybe_generalization := object.get(entity, "MaybeGeneralization", {})
  object.get(maybe_generalization, "Persistable", true) == true

  access_rules := object.get(entity, "AccessRules", [])
  rule := access_rules[_]

  rule.AllowDelete == true

  xpath := object.get(rule, "XPathConstraint", "")
  trim(xpath, " \t\r\n") == ""

  roles := object.get(rule, "AllowedModuleRoles", [])

  err := sprintf("[%v, %v, %v] Entity %v grants Delete access without an XPath constraint (roles: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      entity.Name,
      roles,
    ]
  )
}
