# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: Setting only the key values in retrieve or create microflows is essential for maintaining your application
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: RetrieveOrCreateUseKey
#  severity: MEDIUM
#  rulenumber: 008_0001
#  remediation: Use only the key values as input parameters and use only these to retrieve the object.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# RULE 1: EACH PARAM (OR DERIVED) MUST BE USED IN RETRIEVE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  p := input_parameters[_]
  group := valid_representations[p]


  not exists_in_retrieve_base(group)

  err := sprintf("[%v, %v, %v] Parameter '%v' (or derived: %v) not used in retrieve (retrieve: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      p,
      group,
      retrieve_all
    ]
  )
}


# ---------------------------------------------------------
# MICROFLOW TYPE
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}


contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

# ---------------------------------------------------------
# INPUT PARAMETERS
# ---------------------------------------------------------
input_parameters := {p |
  o := all_microflow_objects[_]
  contains(lower(type_of(o)), "microflowparameter")
  variabletype := object.get(o, "VariableType", null)
  variabletype != null
  not contains(lower(type_of(variabletype)), "ListType")
  p := o.Name
}

# ---------------------------------------------------------
# GROUP INPUT PARAMETER WITH DERIVATIONS INTO REPRESENTATION (2 LEVELS)
# ---------------------------------------------------------

valid_representations[p] := reps if {
  p := input_parameters[_]

  lvl1 := {v |
    pair := param_derivation_lvl1[_]
    pair[0] == p
    v := pair[1]
  }

  lvl2 := {v |
    pair := param_derivation_lvl2[_]
    pair[0] == p
    v := pair[1]
  }

  reps := {p} | lvl1 | lvl2
}

param_derivation_lvl1 := { [p, v] |
  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_xpath_vars(expr)

  vx := vars[_]
  base := base_var(vx)

  input_parameters[base]

  p := base

  v := object.get(act, "VariableName", "")
  v != ""
}

param_derivation_lvl2 := { [p, v2] |
  pair := param_derivation_lvl1[_]
  p := pair[0]
  v1 := pair[1]

  act := actions[_]

  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")

  vars := extract_xpath_vars(expr)

  vx := vars[_]
  base_var(vx) == v1

  v2 := object.get(act, "VariableName", "")
  v2 != ""
}

is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

is_find_filter_operation(operation) if {
  contains(lower(type_of(operation)), "find")
} else if {
  contains(lower(type_of(operation)), "filter")
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------

exists_in_retrieve_base(group) if {
  some v
  group[v]
  retrieve_base[v]
}

# Normalized retrieve (for param coverage only)
retrieve_base := {b |
  v := retrieve_all[_]
  b := base_var(v)
}

retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
} | {v |
  retrieve_find_vars[v]
}

retrieve_find_vars := { v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "listoperationsaction")
  listoperation := object.get(a, "NewOperation", null)
  listoperation != null
  is_find_filter_operation(listoperation)
  expression := object.get(listoperation, "Expression", null)
  expression != null
  v:= extract_xpath_vars(expression)[_]
}

# Assoc retrieve
retrieve_assoc_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_xpath_vars(xpath)[_]
}

# VARIABLE EXTRACTION
extract_xpath_vars(xpath) := vars if {
  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(xpath, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------
# Normalize variable to its base (before '/')
base_var(v) := b if {
  parts := split(v, "/")
  b := parts[0]
}

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }



# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]