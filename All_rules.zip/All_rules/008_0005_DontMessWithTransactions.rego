# METADATA
# scope: package
# title: Disallowed transaction handling Java actions
# description: DontMessWithTransactions
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: DontMessWithTransactions
#  severity: HIGH
#  rulenumber: 008_0005
#  remediation: Use the Mendix TaskQueue when you want to execute logic in batches. Stop/Start transaction do not cleanup commit/delete lists so you might still run out of memory.
#  input: .*\.Microflows\$Microflow\.yaml

package app.mendix.microflow.dontmesswithtransactions

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false

# Policy passes if no errors are found
allow if count(errors) == 0

# ---------------------------------------------------------
# Forbidden Java Actions
# ---------------------------------------------------------
forbidden_java_actions := {
  "objecthandling.starttransaction",
  "objecthandling.endtransaction",
  "communitycommons.starttransaction",
  "communitycommons.endtransaction"
}

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------
errors contains err if {
  a := java_actions[_]

  action_name := lower(object.get(a, "JavaAction", ""))
  action_name != ""

  action_name == forbidden_java_actions[_]

  err := sprintf("[%v, %v, %v] Forbidden Java action used: %v",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      action_name
    ]
  )
}

# ---------------------------------------------------------
# Extract Java actions
# ---------------------------------------------------------
java_actions := [a |
  a := actions[_]
  contains(lower(type_of(a)), "javaaction")
]



# ---------------------------------------------------------
# TYPE HELPER
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if {
  true
}


# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]