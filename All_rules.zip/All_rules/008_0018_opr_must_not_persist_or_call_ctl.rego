# METADATA
# scope: package
# title: OPR_ microflows must not commit, delete or call CTL_ microflows
# description: OPR_ microflows operate on objects in memory only. Commits, deletes and calls to CTL_ microflows belong in CTL_ microflows, so persistence stays in the controller layer.
# authors:
# - Mark van der Smagt
# custom:
#  category: Maintainability
#  rulename: OprMustNotPersistOrCallCtl
#  severity: MEDIUM
#  rulenumber: 008_0018
#  remediation: Rename the microflow prefix from OPR_ to CTL_ when it needs to commit, delete or call CTL_ microflows.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.opr_must_not_persist_or_call_ctl

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

errors contains err if {
  startswith(lower(input.Name), "opr_")
  count(forbidden) > 0

  err := sprintf("[%v, %v, %v] OPR_ microflow '%v' contains forbidden activities: %v",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      input.Name,
      concat(", ", sort(forbidden)),
    ]
  )
}

# ---------------------------------------------------------
# One entry per enabled offending activity. An array rather than a set,
# so every offending activity is listed, duplicates included, at the
# cost of a longer message.
# ---------------------------------------------------------
forbidden := [e |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"
  object.get(aa, "Disabled", false) != true

  a := object.get(aa, "Action", null)
  a != null

  e := forbidden_entry(a)
]

forbidden_entry(a) := sprintf("commit(%v)", [object.get(a, "CommitVariableName", "")]) if {
  lower(type_of(a)) == "microflows$commitaction"
}

# Any Commit value other than "No" counts, so every commit variant is caught
# without depending on its exact spelling; other unexpected values are flagged too.
forbidden_entry(a) := sprintf("commit(%v)", [object.get(a, "ChangeVariableName", "")]) if {
  lower(type_of(a)) == "microflows$changeaction"
  object.get(a, "Commit", "No") != "No"
}

forbidden_entry(a) := sprintf("commit(%v)", [object.get(a, "VariableName", "")]) if {
  lower(type_of(a)) == "microflows$createchangeaction"
  object.get(a, "Commit", "No") != "No"
}

forbidden_entry(a) := sprintf("delete(%v)", [object.get(a, "DeleteVariableName", "")]) if {
  lower(type_of(a)) == "microflows$deleteaction"
}

forbidden_entry(a) := sprintf("CTL_ call(%v)", [target]) if {
  lower(type_of(a)) == "microflows$microflowcallaction"
  target := object.get(object.get(a, "MicroflowCall", {}), "Microflow", "")
  parts := split(target, ".")
  startswith(lower(parts[count(parts) - 1]), "ctl_")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Preferred display name for an activity in lint messages.
# Caption is the modeler-facing label, but it's frequently left blank -
# fall back to the variable the activity assigns its result to
# (ResultVariableName, or VariableName for the activity kinds that use
# that field instead), and only fall back further to the raw activity
# type if neither is set.
#
# Depends on: type_of.rego.part
# ---------------------------------------------------------
activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "ResultVariableName", "")
  c0 != ""
  c := c0
} else := c if {
  c0 := object.get(aa, "VariableName", "")
  c0 != ""
  c := c0
} else := type_of(aa) if { true }

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# The set of ErrorHandlingType values (after normalize_eht) that
# count as "custom" error handling.
# Note: 008_0003 originally called this constant allowed_error_handling
# and 008_0004 called it allowed_custom_error_handling - same value,
# different name. Standardized on allowed_custom_error_handling.
# ---------------------------------------------------------
allowed_custom_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables derived from $latestError via a Create or Change variable
# action whose InitialValue/Value contains "$latestError" (e.g.
# $ErrorMsg := $latestError/Message). Lets a rule recognize error-handling
# code that references the error indirectly through such a variable, not
# just $latestError itself.
#
# Was previously hand-duplicated (byte-for-byte) inside both
# 008_0004_custom_error_handling_latest_error_usage.rule.part and
# 008_0015_no_raw_error_messages_to_user.rule.part - consolidated here.
#
# Depends on: microflow_object_tree.rego.part (actions),
#             is_create_variable_action.rego.part,
#             is_change_variable_action.rego.part
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
  act := actions[_]
  is_create_variable_action(act)

  expr := object.get(act, "InitialValue", "")
  contains(expr, "$latestError")

  v := object.get(act, "VariableName", "")
  v != ""
}

derived_change_vars := {v |
  act := actions[_]
  is_change_variable_action(act)

  expr := object.get(act, "Value", "")
  contains(expr, "$latestError")

  v := object.get(act, "ChangeVariableName", "")
  v != ""
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Normalizes an ErrorHandlingType value (e.g. "Custom With Rollback",
# "custom_with_rollback") down to a comparable lowercase-letters-only
# form, e.g. "customwithrollback".
# ---------------------------------------------------------
normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Pulls every $Variable reference out of an XPath constraint or any other
# microflow expression string (list-operation filters, decision-split
# conditions, ...).
# ---------------------------------------------------------
extract_variables(expr) := vars if {
  # Mendix can export (or a modeler can author) an expression with a
  # literal line break landing inside a compound $Var/Association path,
  # e.g. "$HouseHold/\nAddress" instead of "$HouseHold/Address". Rejoin
  # a newline that touches a "/" before treating whitespace as a token
  # separator below, or the segment after the break (here "Address")
  # gets silently dropped since it no longer starts with "$". Only a
  # newline-containing whitespace run adjacent to "/" is collapsed here
  # - plain spaces around "/" (e.g. "$Amount / 2") are left untouched,
  # so this can't merge two space-separated $Var tokens either side of
  # a division operator.
  step1 := regex.replace(expr, `/[ \t]*\r?\n[ \t\r\n]*`, "/")
  rejoined := regex.replace(step1, `[ \t\r\n]*\r?\n[ \t]*/`, "/")

  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(rejoined, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_change_variable_action(a) if {
  contains(lower(type_of(a)), "changevariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Depends on: type_of.rego.part
# ---------------------------------------------------------
is_create_variable_action(a) if {
  contains(lower(type_of(a)), "createvariableaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Flattens a microflow's nested ObjectCollection.Objects tree
# (up to 4 levels of nesting, e.g. inside loops/exclusive splits)
# into one array, and extracts the Action of every ActionActivity.
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]

# An array, not a set, so that byte-for-byte identical objects (e.g. two
# identical LogMessage activities) each keep their own entry for rules
# that count occurrences.
all_microflow_objects := array.concat(
  array.concat(
    array.concat(microflow_objects_lvl0, microflow_objects_lvl1),
    array.concat(microflow_objects_lvl2, microflow_objects_lvl3)
  ),
  microflow_objects_lvl4
)

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Identifies "retrieve or create" pattern microflows by name,
# and whether they delegate to another microflow (in which case
# the retrieve/create checks that live in the caller don't apply).
# Depends on: microflow_object_tree.rego.part (actions)
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Variables read via a database Retrieve action, either through
# an association path or an XPath constraint.
# Depends on: microflow_object_tree.rego.part (actions),
#             extract_variables.rego.part
# ---------------------------------------------------------

# Assoc retrieve
retrieve_assoc_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPATH VARIABLE Retrieve
retrieve_xpath_vars := {v |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_variables(xpath)[_]
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Deep traversal: collect every string value nested anywhere
# inside an object (used to scan expressions/log messages for
# a substring regardless of which field it's stored in).
#
# Note: standardized to a set here. The original 008_0004 had this
# as an array comprehension, but every call site only ever iterates
# it with `strings_in_object(x)[_]`, which is order-independent, so
# using a set here is behavior-preserving for both callers.
# ---------------------------------------------------------
strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}

#  input: .*\.Microflows\$Microflow\.yaml

# ---------------------------------------------------------
# Type accessor: Mendix modelsource YAML uses either $Type or
# $type depending on export version.
# ---------------------------------------------------------
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }
