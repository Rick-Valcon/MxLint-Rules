# METADATA
# scope: package
# title: Error-prone activities must use custom error handling
# description: Enforces Custom error handling (with or without rollback) for error-prone activities. Error-prone activities are either (1) explicitly risky action types (Java actions, import/export mappings) or (2) any action that contains error-prone expression functions (e.g., parseDateTime, substring) anywhere within its Action definition.
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: ErrorProneActivitiesMustUseCustomErrorHandling
#  severity: MEDIUM
#  rulenumber: 008_0003
#  remediation: For error prone activities, set ErrorHandlingType to CustomWithRollback or CustomWithoutRollBack explicitly and write a logmessage that contains the $latestError, the microflow in which the error occured, the specific activity that caused the error, the user triggering the error and any usefull context information (e.g OrderId).
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.error_prone_custom_error_handling

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# Maintainable config
# ---------------------------------------------------------

error_prone_action_types := [
  {"match": "microflows$javaactioncallaction", "label": "Java action"},
  {"match": "microflows$importxmlaction",      "label": "Import mapping (ImportXmlAction)"},
  {"match": "microflows$restcallaction",      "label": "Call REST"},
  {"match": "microflows$restoperationcallaction",      "label": "Send REST request"},
  {"match": "microflows$callwebserviceaction",      "label": "Call Web Service"},
  {"match": "microflows$callexternalaction",      "label": "Call external action"},
  {"match":  "exceldataimporter$importexceldataaction", "label": "Data Importer Mapping"},
  {"match":  "microflows$Downloadfileaction", "label": "Download file"}
  
]

error_prone_expression_functions := {
  "substring",
  "parseDateTime",
  "parseDateTimeUTC",
  "parseDecimal"
}

allowed_error_handling := {
  "customwithrollback",
  "customwithoutrollback",
  "custom"
}

whitelisted_java_actions := {
  "objecthandling.starttransaction", #Error handling will not work on this java action, additonally these are already flagged by rule 008_005_DontMessWithTransactions
  "objecthandling.endtransaction",
  "communitycommons.starttransaction",
  "communitycommons.endtransaction",
  "communitycommons.commitinseparatedatabasetransaction",
  "communitycommons.getguid", #Sometimes used in loops and almost never fails
  "communitycommons.randomhash", #Not dependent on context, never fails
  "communitycommons.throwexception", #Adding error handling here would defeat the purpose
  "communitycommons.throwwebserviceexception", #Adding error handling here would defeat the purpose
  "communitycommons.getruntimeversion", #Not dependent on context, never fails
  "communitycommons.getmodelversion", #Not dependent on context, never fails
  "communitycommons.getapplicationurl", #Not dependent on context, never fails
  "communitycommons.isindevelopment", #Not dependent on context, never fails
  "mxmodelreflection.syncobjects", #Admin action, not dependent on context
  "communitycommons.delay", #Not dependent on context
  "communitycommons.timemeasurestart", #Not dependent on context
  "communitycommons.timemeasureend"  #Not dependent on context
}

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------


errors contains err if {
  ep := error_prone_expressions[_]
  a := ep.action

  not error_handling_ok(a)

  err := sprintf("[%v, %v, %v] %v contains error-prone expressions %v and must use custom error handling",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      ep.caption,
      ep.functions
      
    ]
  )
}


errors contains err if {
  ep := error_prone_activities[_]
  a := ep.action
  
  not error_handling_ok(a)
  display := action_display_name(a, ep.kind)

  err := sprintf("[%v, %v, %v] %v must use custom error handling",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      display
    ]
  )
}


# ---------------------------------------------------------
# Determine which activities are error-prone
# ---------------------------------------------------------

error_prone_activities := [info |
  a := actions[_]

  label := error_prone_label(a)
  label != ""
  not is_whitelisted_java_action(a)

  info := {
    "action": a,
    "caption": activity_caption(a),
    "kind": label
  }
]

# ---------------------------------------------------------
# Determine which expressions are error-prone
# ---------------------------------------------------------

error_prone_expressions := [info |
  a := actions[_]


  funcs := error_prone_functions_in_action(a)
  count(funcs) > 0

  info := {
    "action": a,
    "caption": activity_caption(a),
    "functions": funcs
  }
]


error_prone_label(a) := label if {
  t := lower(type_of(a))
  d := error_prone_action_types[_]
  contains(t, d.match)
  label := d.label

  # ✅ skip whitelisted Java actions
  not is_whitelisted_java_action(a)

}



error_prone_functions_in_action(a) := funcs if {
  funcs := {fn |
    some s in strings_in_object(a)
    e := lower(s)
    fn := error_prone_expression_functions[_]
    contains(e, sprintf("%v(", [fn]))
  }
} else := {} if { true }



# ---------------------------------------------------------
# Caption helper (preferred action name in output)
# ---------------------------------------------------------

activity_caption(aa) := c if {
  c0 := object.get(aa, "Caption", "")
  c0 != ""
  c := c0
} else := "UNKNOWN" if { true }

# ---------------------------------------------------------
# Expression scanning (type-independent)
# ---------------------------------------------------------


strings_in_object(x) := {s |
  some path, v
  walk(x, [path, v])
  is_string(v)
  s := v
}


# ---------------------------------------------------------
# Error handling checks
# ---------------------------------------------------------

error_handling_ok(a) if {
  eht_raw := object.get(a, "ErrorHandlingType", "")
  eht_raw != ""
  eht := normalize_eht(eht_raw)
  eht in allowed_error_handling
}

normalize_eht(s) := out if {
  lower_s := lower(s)
  no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
  chars := [c | c := split(no_sep, "")[_]; is_letter(c)]
  out := concat("", chars)
}

is_letter(c) if {
  c >= "a"
  c <= "z"
}

# ---------------------------------------------------------
# Microflow traversal helpers
# ---------------------------------------------------------

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }

#whitelisted java actions

is_whitelisted_java_action(a) if {
  contains(lower(type_of(a)), "javaactioncallaction")

  action_name := lower(object.get(a, "JavaAction", ""))
  action_name != ""

  action_name == whitelisted_java_actions[_]
}



action_display_name(a, kind) := name if {
  is_java_action(a)

  raw := java_action_name(a)
  name := raw
} else := kind if {
  not is_java_action(a)
}



java_action_name(a) := name if {
  name := object.get(a, "JavaAction", "")
  name != ""
} else := "Unknown JavaAction" if { true }



  
is_java_action(a) if {
  contains(lower(type_of(a)), "javaactioncallaction")
}


# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]