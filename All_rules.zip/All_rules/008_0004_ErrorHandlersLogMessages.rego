
# METADATA
# scope: package
# title: Custom error handling must use latestError
# description: Errors should always be logged
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: CustomErrorHandlingMustUseLatestError
#  severity: HIGH
#  rulenumber: 008_0004
#  remediation: Log all relevant information. ErrorType, ErrorMessage, CurrentUser, MicroflowName, specific Activity, Contex attributes.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.microflows.custom_error_handling_latest_error_usage

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

allowed_custom_error_handling := {
    "customwithrollback",
    "customwithoutrollback",
    "custom"
}

# ---------------------------------------------------------
# Main error: handler count must be equal or exceed custom count
# ---------------------------------------------------------
errors contains err if {
    custom_cnt := count(custom_handled_actions
)
    custom_cnt > 0

    handler_cnt := count(valid_error_handler_activities)
    handler_cnt < custom_cnt

    missing := custom_cnt - handler_cnt

    err := sprintf(
        "[%v, %v, %v] Custom error handling used %v time(s) but $latestError is only used %v times.",
        [
            annotation.custom.severity,
            annotation.custom.category,
            annotation.custom.rulenumber,
            custom_cnt,
            handler_cnt
        ],
    )
}

# ---------------------------------------------------------
# Custom-handled activities
# ---------------------------------------------------------
custom_handled_actions := [info |
    act := actions[i]

    eht_norm := normalize_eht(object.get(act, "ErrorHandlingType", ""))
    eht_norm in allowed_custom_error_handling

    info := {
        "idx": i,
        "caption": activity_caption(act),
        "type": type_of(act),
    }
]

# ---------------------------------------------------------
# Valid handlers (union): LogMessage handlers OR MicroflowCall handlers
# ---------------------------------------------------------
valid_error_handler_activities := log_handler_activities | microflow_handler_activities

log_handler_activities := {i |
    act := actions[i]

    is_log_message_action(act)

    derived := derived_error_vars
    uses_latest_error_or_derived_in_strings(act, derived)
}

microflow_handler_activities := {i |
    act := actions[i]

    is_microflow_call_action(act)

    derived := derived_error_vars
    microflow_call_uses_latest_error_or_derived(act, derived)
}

# ---------------------------------------------------------
# Derived variables from latestError (Create/Change variable)
# ---------------------------------------------------------
derived_error_vars := derived_create_vars | derived_change_vars

derived_create_vars := {v |
    act := actions[_]

    is_create_variable_action(act)

    expr := object.get(act, "InitialValue", "")
    contains(expr, "$latestError")

    v := object.get(act, "VariableName", "")
    v != ""
}

derived_change_vars := {v |
    act := actions[_]

    is_change_variable_action(act)

    expr := object.get(act, "Value", "")
    contains(expr, "$latestError")

    v := object.get(act, "ChangeVariableName", "")
    v != ""
}

# ---------------------------------------------------------
# LogMessage check: scan ALL strings in the LogMessage action
# Accepts $latestError and $latestError/Message (both contain "$latestError")
# Accepts derived vars like $Variable
# ---------------------------------------------------------
uses_latest_error_or_derived_in_strings(act, derived) if {
    s := strings_in_object(act)[_]
    contains(s, "$latestError")
}

uses_latest_error_or_derived_in_strings(act, derived) if {
    s := strings_in_object(act)[_]
    v := derived[_]
    contains(s, sprintf("$%v", [v]))
}

# ---------------------------------------------------------
# MicroflowCall check: inspect ParameterMappings[].Argument
# Accepts $latestError and $latestError/Message
# Accepts derived vars like $InputParameter
# ---------------------------------------------------------
microflow_call_uses_latest_error_or_derived(act, derived) if {
    call := object.get(act, "MicroflowCall", null)
    call != null

    mappings := object.get(call, "ParameterMappings", [])
    m := mappings[_]

    arg := object.get(m, "Argument", "")
    contains(arg, "$latestError")
}

microflow_call_uses_latest_error_or_derived(act, derived) if {
    call := object.get(act, "MicroflowCall", null)
    call != null

    mappings := object.get(call, "ParameterMappings", [])
    m := mappings[_]

    arg := object.get(m, "Argument", "")
    v := derived[_]
    contains(arg, sprintf("$%v", [v]))
}

# ---------------------------------------------------------
# Deep traversal: collect all strings inside an object
# ---------------------------------------------------------
strings_in_object(x) := [s |
    some path, v
    walk(x, [path, v])
    is_string(v)
    s := v
]

# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
normalize_eht(s) := out if {
    lower_s := lower(s)
    no_sep := replace(replace(replace(lower_s, " ", ""), "_", ""), "-", "")
    chars := [c |
        c := split(no_sep, "")[_]
        is_letter(c)
    ]
    out := concat("", chars)
}

is_letter(c) if {
    c >= "a"
    c <= "z"
}

activity_caption(aa) := c if {
    c0 := object.get(aa, "Caption", "")
    c0 != ""
    c := c0
} else := "UNKNOWN" if {
    true
}

# ---------------------------------------------------------
# Type checks
# ---------------------------------------------------------
is_log_message_action(a) if {
    contains(lower(type_of(a)), "logmessageaction")
}

is_microflow_call_action(a) if {
    contains(lower(type_of(a)), "microflowcallaction")
}

is_create_variable_action(a) if {
    contains(lower(type_of(a)), "createvariableaction")
}

is_change_variable_action(a) if {
    contains(lower(type_of(a)), "changevariableaction")
}

type_of(x) := t if {
    t := x["$Type"]
} else := t if {
    t := x["$type"]
} else := "" if {
    true
}


# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]