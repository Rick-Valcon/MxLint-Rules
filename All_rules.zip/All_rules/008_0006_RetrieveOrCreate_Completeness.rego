# METADATA
# scope: package
# title: Incorrect RetrieveOrCreate pattern
# description: The create must match the retrieve or duplicate objects will be created.
# authors:
# - Mark van der Smagt
# custom:
#  category: Reliability
#  rulename: RetrieveOrCreateCompleteness
#  severity: HIGH
#  rulenumber: 008_0006
#  remediation: Make sure that the created object matches the entity and attributes that are being retrieved. Also make sure that the created object is used as return parameter.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0


# ---------------------------------------------------------
# RULE 1: RETRIEVE VARIABLES MUST EXIST IN CREATE
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  missing := {x |
    x := retrieve_all[_]
    not create_all[x]
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] Not all variables used in retrieve are set in create (retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      retrieve_all,
      create_all
    ]
  )
}

# ---------------------------------------------------------
# RULE 2: ENTITY MATCH
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  retrieve := database_retrieve_entity
  count(retrieve) != 0

  create := create_entity

  missing := {x |
    some i
    x := create[i]
    not retrieve[x] #True if retrieve contains x
  }

  count(missing) > 0

  err := sprintf("[%v, %v, %v] Retrieved and created entities differ (retrieve: %v, create: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      retrieve,
      create
    ]
  )
}

# ---------------------------------------------------------
# RULE 3: END EVENTS MUST RETURN DIFFERENT VARIABLES
# ---------------------------------------------------------
errors contains err if {
  is_retrieve_or_create_microflow
  not contains_microflowcall

  # Collect all end event return values
  returns := {rv |
    o := all_microflow_objects[_]
    contains(lower(type_of(o)), "endevent")

    raw := object.get(o, "ReturnValue", "")
    raw != ""

    # normalize
    without_dollar := trim_prefix(raw, "$")
    rv := trim(without_dollar, " \t\r\n")
  }

  # if duplicates exist, count(set) < count(all occurrences)
  count(returns) < count([rv |
    o := all_microflow_objects[_]
    contains(lower(type_of(o)), "endevent")

    raw := object.get(o, "ReturnValue", "")
    raw != ""

    without_dollar := trim_prefix(raw, "$")
    rv := trim(without_dollar, " \t\r\n")
  ])

  err := sprintf("[%v, %v, %v] End events must return different variables (found: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      returns
    ]
  )
}

# ---------------------------------------------------------
# MICROFLOW TYPE
# ---------------------------------------------------------
is_retrieve_or_create_microflow if {
  name := lower(input.Name)
  contains(name, "retrieve")
  contains(name, "create")
}

contains_microflowcall if{
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "microflowcallaction")
}

# ---------------------------------------------------------
# RETRIEVE VARIABLES
# ---------------------------------------------------------
exists_in_retrieve(group) if {
  some v
  group[v]
  retrieve_all[v]
}

retrieve_all := {v |
  retrieve_assoc_vars[v]
} | {v |
  retrieve_xpath_vars[v]
}

# Assoc retrieve
retrieve_assoc_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource","")
  contains(lower(object.get(src, "$Type", "")), "associationretrievesource")

  v := object.get(src, "StartVariableName", "")
  v != ""
}

# XPath retrieve
retrieve_xpath_vars := {v | 
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null
  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""

  v := extract_xpath_vars(xpath)[_]
}

# VARIABLE EXTRACTION
extract_xpath_vars(xpath) := vars if {
  normalized := replace(replace(replace(replace(replace(replace(replace(replace(replace(xpath, "[", " "), "]", " "), "AND", " "), "OR", " "), ")", " "), "(", " ") ,"\t"," "),"\r"," "),"\n"," ")
  parts := split(normalized, " ")

  vars := {trim_prefix(trim(p, " "), "$") |
    p := parts[_]
    startswith(p, "$")
  }
}

# ---------------------------------------------------------
# CREATE VARIABLES
# ---------------------------------------------------------

create_all := {v |
  used_variables_in_create[v]
}


used_variables_in_create := {vd |
  a := actions[_]
  contains(lower(object.get(a, "$Type", "")), "changeaction")

  items := object.get(a, "Items", [])
  item := items[_]

  val := object.get(item, "Value", "")
  startswith(val, "$")

  raw := trim_prefix(val, "$")
  vd := trim(raw, " \t\r\n")
}

# ---------------------------------------------------------
# ENTITY EXTRACTION
# ---------------------------------------------------------
database_retrieve_entity := {ent |
  a := actions[_]
  contains(lower(type_of(a)), "retrieveaction")

  src := object.get(a, "RetrieveSource", null)
  src != null

  contains(lower(object.get(src, "$Type", "")), "databaseretrievesource")

  ent := object.get(src, "Entity", "")
  ent != ""
}

create_entity := {ent |
  a := actions[_]
  is_create_change_action(a)
  ent := a.Entity
}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------

is_create_change_action(a) if {
  contains(lower(type_of(a)), "changeaction")
}

type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if { true }


# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]