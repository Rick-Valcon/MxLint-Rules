# METADATA
# scope: package
# title: Cast current user
# description: If there is a currentUser, it is already in context which makes a database call unneeded
# authors:
# - Mark van der Smagt
# custom:
#  category: Performance
#  rulename: CastCurrentUser
#  severity: MEDIUM
#  rulenumber: 008_0002
#  remediation: Retrieve the current user from context, if you need a specialisation, use a cast activity.
#  input: .*\.Microflows\$Microflow\.yaml
package app.mendix.domain_model.retrieveorcreate_use_key

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false

# Policy passes if no errors are found
allow if count(errors) == 0

# ---------------------------------------------------------
# Error: Retrieve currentUser from database
# ---------------------------------------------------------
errors contains err if {
  a := actions[_]
  is_retrieve_action(a)

  src := object.get(a, "RetrieveSource", null)
  src != null

  src_type := object.get(src, "$Type", "")
  contains(lower(src_type), "databaseretrievesource")

  xpath := object.get(src, "XpathConstraint", "")
  xpath != ""
  xpath_retrieves_currentUser(xpath)

  err := sprintf("[%v, %v, %v] Retrieving currentUser via database is unnecessary (xpath: %v)",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      xpath
    ]
  )
}

is_retrieve_action(a) if {
  contains(lower(type_of(a)), "retrieveaction")
}

# TYPE HELPER

# Safely extract $Type or $type
type_of(x) := t if {
  t := x["$Type"]
} else := t if {
  t := x["$type"]
} else := "" if {
  true
}

xpath_retrieves_currentUser(xpath) if {
  noWhitespace := replace(xpath, " ", "")
  contains(noWhitespace, "id=$currentUser")
}

xpath_retrieves_currentUser(xpath) if {
  noWhitespace := replace(xpath, " ", "")
  contains(noWhitespace, "$currentUser=id")
}

# ---------------------------------------------------------
# ACTION COLLECTION
# ---------------------------------------------------------
actions := [a |
  aa := all_microflow_objects[_]
  aa["$Type"] == "Microflows$ActionActivity"

  a := object.get(aa, "Action", null)
  a != null
]


# ---- 
# RETRIEVE OBJECTS
# ----

all_microflow_objects := objs if {
  objs := {o |
    o := microflow_objects_lvl0[_]
  } |
  {o |
    o := microflow_objects_lvl1[_]
  } |
  {o |
    o := microflow_objects_lvl2[_]
  } |
  {o |
    o := microflow_objects_lvl3[_]
  } |
  {o |
    o := microflow_objects_lvl4[_]
  }
}

microflow_objects_lvl0 := input.ObjectCollection.Objects

microflow_objects_lvl1 := [o |
  parent := microflow_objects_lvl0[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl2 := [o |
  parent := microflow_objects_lvl1[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl3 := [o |
  parent := microflow_objects_lvl2[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]

microflow_objects_lvl4 := [o |
  parent := microflow_objects_lvl3[_]

  oc := object.get(parent, "ObjectCollection", null)
  oc != null

  o := object.get(oc, "Objects", [])[_]
]