# METADATA
# scope: package
# title: Disable_entity_create_rights
# description: Always govern creation rights through microflow and disable the rights on entity level.
# authors:
# - Lucas van Dongen
# custom:
#  category: Security
#  rulename: NoCreateRights
#  severity: MEDIUM
#  rulenumber: 007_0006
#  remediation: Use microflow rights instead.
#  input: .*DomainModels\$DomainModel\.yaml

package app.mendix.domain_model.do_not_allow_create

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

is_array(x) if {
    type_name(x) == "array"
}

errors contains error if {
    entity := input.Entities[_]

    access_rules := object.get(entity, "AccessRules", null)
    is_array(access_rules)

    access_rule := access_rules[_]
    object.get(access_rule, "AllowCreate", false) == true

    error := sprintf(
        "[%v, %v, %v] Entity %v has AllowCreate set to true",
        [
            annotation.custom.severity,
            annotation.custom.category,
            annotation.custom.rulenumber,
            entity.Name
        ]
    )
}
