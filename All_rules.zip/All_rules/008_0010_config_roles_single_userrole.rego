# METADATA
# scope: package
# title: Sensitive module configuration role assigned too broadly
# description: Encryption.User, ExcelImporter.Configurator, ExcelExporter.Configuration, XLSReport.Configurator, and MassUpload.Configurator gate sensitive configuration/encryption permissions and should be granted narrowly. Assigning one of them to more than one user role broadens that access unnecessarily, and granting one to the project's anonymous/guest user role exposes it to unauthenticated users entirely.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: ConfigRolesSingleUserRole
#  severity: HIGH
#  rulenumber: 008_0010
#  remediation: Assign Encryption.User, ExcelImporter.Configurator, ExcelExporter.Configuration, XLSReport.Configurator, and MassUpload.Configurator to exactly one dedicated user role each, and make sure none of them are granted to the project's anonymous/guest user role.
#  input: .*Security\$ProjectSecurity\.yaml
package app.mendix.security.config_roles_single_userrole

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

sensitive_module_roles := {
  "Encryption.User",
  "ExcelImporter.Configurator",
  "ExcelExporter.Configuration",
  "XLSReport.Configurator",
  "MassUpload.Configurator",
}

# ---------------------------------------------------------
# RULE 1: sensitive module role assigned to more than one user role
# ---------------------------------------------------------
errors contains err if {
  role_name := sensitive_module_roles[_]
  holders := holders_of(role_name)
  count(holders) > 1

  err := sprintf("[%v, %v, %v] Module role %v is assigned to more than one user role: %v",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      role_name,
      holders,
    ]
  )
}

# ---------------------------------------------------------
# RULE 2: the project's anonymous/guest user role holds a sensitive
# module role - always a violation, regardless of how many user roles
# hold it in total. Only meaningful while guest access is enabled.
# ---------------------------------------------------------
errors contains err if {
  object.get(input, "EnableGuestAccess", false) == true

  guest := object.get(input, "GuestUserRole", "")
  guest != ""

  role_name := sensitive_module_roles[_]
  guest in holders_of(role_name)

  err := sprintf("[CRITICAL, %v, %v] Anonymous user role %v is granted the sensitive module role %v",
    [
      annotation.custom.category,
      annotation.custom.rulenumber,
      guest,
      role_name,
    ]
  )
}

# ---------------------------------------------------------
# The names of every UserRole whose ModuleRoles list contains
# role_name.
# ---------------------------------------------------------
holders_of(role_name) := {name |
  ur := input.UserRoles[_]
  role_name in object.get(ur, "ModuleRoles", [])
  name := ur.Name
}
