# METADATA
# scope: package
# title: Published REST service must require authentication
# description: A Published REST Service with no AuthenticationTypes configured is reachable by anyone without credentials, exposing its data and functionality to unauthorized access.
# authors:
# - Mark van der Smagt
# custom:
#  category: Security
#  rulename: PublishedRestServiceRequiresAuthentication
#  severity: HIGH
#  rulenumber: 008_0014
#  remediation: Configure at least one entry in AuthenticationTypes for the published REST service, and assign AllowedRoles.
#  input: .*\.Rest\$PublishedRestService\.yaml
package app.mendix.security.rest_service_requires_authentication

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

# ---------------------------------------------------------
# A published REST service with no authentication type configured has
# no auth mechanism at all. AuthenticationMicroflow is not checked here:
# Mendix will not run a model where AuthenticationTypes includes Microflow
# without one configured, so that combination can't occur, and several
# valid AuthenticationTypes (e.g. Basic) don't use a microflow at all.
# ---------------------------------------------------------
errors contains err if {
  auth_types := object.get(input, "AuthenticationTypes", [])
  count(auth_types) == 0

  err := sprintf("[%v, %v, %v] Published REST service %v (%v) has no AuthenticationTypes configured - it is reachable without authentication.",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      object.get(input, "ServiceName", object.get(input, "Name", "UNKNOWN")),
      object.get(input, "Path", ""),
    ]
  )
}
